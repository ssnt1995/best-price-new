package com.example.sushant.best_price;

/**
 * Created by Sushant Sharma on 07-May-17.
 */

public class IpAddress {

    public static String ip = "192.168.0.26";
}
